
module.exports = class Component {
    constructor() {
    }
    
    printDescription (){
    }

    removeChild (Component){
    }

    addChild (Component){
    }

    getChild (key){
    }
}