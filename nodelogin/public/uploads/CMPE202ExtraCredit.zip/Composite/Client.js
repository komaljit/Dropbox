var BuildOrder=require('./BuildOrder.js');

let c=BuildOrder.getOrder();
c.printDescription();