module.exports = class Handler {
    constructor() {
    }
    
    handleRequest (request){
    }

    setSuccessor (next){
    }

}