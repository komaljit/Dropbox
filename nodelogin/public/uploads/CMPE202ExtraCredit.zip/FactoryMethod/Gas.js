
var Engine=require('./Engine.js');

module.exports=class Gas extends Engine {

}