
var Engine=require('./Engine.js');

module.exports=class Electric extends Engine {

}