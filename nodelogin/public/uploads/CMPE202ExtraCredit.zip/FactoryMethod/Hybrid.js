
var Engine=require('./Engine.js');

module.exports=class Hybrid extends Engine {

}
