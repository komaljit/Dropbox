module.exports=class Component {

	constructor(){
		
	}
	
	operation(){
		
	}

}